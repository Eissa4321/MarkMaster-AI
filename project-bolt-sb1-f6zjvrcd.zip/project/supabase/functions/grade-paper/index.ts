const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const MODEL = "gemini-2.5-flash";
const ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;
const ACCEPTED_MIME_TYPES = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/heic",
  "image/heif",
  "text/plain",
];
const MAX_BASE64_CHARS = 5_500_000;

const PROMPT = `You are a senior IGCSE and A-Level examiner. You are given a STUDENT PAPER (the student's answers) and the MARK SCHEME for the same paper.
Mark the student's answers strictly against the mark scheme, awarding marks question by question.
- score: total marks awarded. maxScore: total marks available.
- percentage: score / maxScore * 100, rounded to the nearest whole number.
- missedKeywords: key terms or command words from the mark scheme that the student omitted or used incorrectly.
- strengths and improvements: concise, specific, actionable points for the student.
- questionBreakdown: one entry per question or part with marksAwarded, maxMarks and a short comment explaining the award.
- summary: two or three sentences on overall performance and the single most important next step.
Respond only with JSON matching the schema.`;

const RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    score: { type: "NUMBER" },
    maxScore: { type: "NUMBER" },
    percentage: { type: "NUMBER" },
    summary: { type: "STRING" },
    missedKeywords: { type: "ARRAY", items: { type: "STRING" } },
    strengths: { type: "ARRAY", items: { type: "STRING" } },
    improvements: { type: "ARRAY", items: { type: "STRING" } },
    questionBreakdown: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          question: { type: "STRING" },
          marksAwarded: { type: "NUMBER" },
          maxMarks: { type: "NUMBER" },
          comment: { type: "STRING" },
        },
        required: ["question", "marksAwarded", "maxMarks", "comment"],
      },
    },
  },
  required: [
    "score",
    "maxScore",
    "percentage",
    "summary",
    "missedKeywords",
    "strengths",
    "improvements",
    "questionBreakdown",
  ],
};

interface UploadedFile {
  mimeType: string;
  data: string;
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function isUploadedFile(value: unknown): value is UploadedFile {
  if (!value || typeof value !== "object") return false;
  const file = value as Record<string, unknown>;
  return (
    typeof file.mimeType === "string" &&
    ACCEPTED_MIME_TYPES.includes(file.mimeType) &&
    typeof file.data === "string" &&
    file.data.length > 0
  );
}

function normalizeResult(raw: unknown) {
  const data = raw as Record<string, unknown> | null;
  if (!data || typeof data.score !== "number" || typeof data.maxScore !== "number") {
    throw new Error("The grader returned an unexpected response. Please try again.");
  }
  const score = data.score;
  const maxScore = data.maxScore;
  return {
    score,
    maxScore,
    percentage:
      typeof data.percentage === "number"
        ? data.percentage
        : Math.round((score / maxScore) * 100),
    summary: typeof data.summary === "string" ? data.summary : "",
    missedKeywords: Array.isArray(data.missedKeywords) ? data.missedKeywords : [],
    strengths: Array.isArray(data.strengths) ? data.strengths : [],
    improvements: Array.isArray(data.improvements) ? data.improvements : [],
    questionBreakdown: Array.isArray(data.questionBreakdown) ? data.questionBreakdown : [],
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return jsonResponse({ error: "Grading is not available right now. Please try again later." }, 503);
    }

    const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    const studentFile = body?.studentFile;
    const schemeFile = body?.schemeFile;

    if (!isUploadedFile(studentFile) || !isUploadedFile(schemeFile)) {
      return jsonResponse({ error: "Both files are required in a supported format." }, 400);
    }
    if (studentFile.data.length + schemeFile.data.length > MAX_BASE64_CHARS) {
      return jsonResponse({ error: "The two files together are too large. Try smaller scans." }, 413);
    }

    const geminiResponse = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              { text: PROMPT },
              { text: "STUDENT PAPER:" },
              { inlineData: { mimeType: studentFile.mimeType, data: studentFile.data } },
              { text: "MARK SCHEME:" },
              { inlineData: { mimeType: schemeFile.mimeType, data: schemeFile.data } },
            ],
          },
        ],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: RESPONSE_SCHEMA,
          temperature: 0.2,
        },
      }),
    });

    const payload = await geminiResponse.json().catch(() => null);

    if (!geminiResponse.ok) {
      const message = payload?.error?.message ?? `Gemini request failed (status ${geminiResponse.status}).`;
      return jsonResponse({ error: message }, 502);
    }

    const text: string | undefined = payload?.candidates?.[0]?.content?.parts
      ?.map((part: { text?: string }) => part.text ?? "")
      .join("");

    if (!text) {
      return jsonResponse({ error: "The grader did not return a result. The files may have been blocked." }, 502);
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      return jsonResponse({ error: "The grader returned unreadable results. Please try again." }, 502);
    }

    return jsonResponse(normalizeResult(parsed));
  } catch (err) {
    const message = err instanceof Error ? err.message : "Something went wrong while grading.";
    return jsonResponse({ error: message }, 500);
  }
});
