import { useMemo, useState } from 'react';
import { Plus } from 'lucide-react';
import DayAgenda from '@/components/calendar/DayAgenda';
import LogTopicModal from '@/components/calendar/LogTopicModal';
import MonthGrid from '@/components/calendar/MonthGrid';
import UpcomingReminders from '@/components/calendar/UpcomingReminders';
import { todayKey } from '@/lib/dates';
import type { CalendarEvent } from '@/types';

interface RevisionCalendarPageProps {
  events: CalendarEvent[];
  onToggleEvent: (id: string) => void;
  onDeleteEvent: (id: string) => void;
  onLogTopic: (topic: string, startDate: string) => void;
}

function startOfCurrentMonth(): Date {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), 1);
}

export default function RevisionCalendarPage({
  events,
  onToggleEvent,
  onDeleteEvent,
  onLogTopic,
}: RevisionCalendarPageProps) {
  const today = todayKey();
  const [month, setMonth] = useState<Date>(startOfCurrentMonth);
  const [selectedDate, setSelectedDate] = useState<string>(today);
  const [isLogging, setIsLogging] = useState(false);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      const list = map.get(event.date) ?? [];
      list.push(event);
      map.set(event.date, list);
    }
    return map;
  }, [events]);

  const upcoming = useMemo(
    () =>
      events
        .filter((event) => !event.done && event.date >= today)
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 6),
    [events, today],
  );

  const selectedEvents = eventsByDate.get(selectedDate) ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50 sm:text-3xl">
            Revision Calendar
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Graded papers and spaced reviews are logged here automatically.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setIsLogging(true)}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-sky-500/20 transition-all hover:-translate-y-0.5 hover:bg-sky-400"
        >
          <Plus className="h-4 w-4" />
          Log Study Topic
        </button>
      </div>

      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <MonthGrid
          month={month}
          selectedDate={selectedDate}
          todayKey={today}
          eventsByDate={eventsByDate}
          onMonthChange={setMonth}
          onSelectDate={setSelectedDate}
        />
        <div className="flex flex-col gap-6">
          <DayAgenda
            date={selectedDate}
            events={selectedEvents}
            onToggle={onToggleEvent}
            onDelete={onDeleteEvent}
          />
          <UpcomingReminders events={upcoming} onToggle={onToggleEvent} onDelete={onDeleteEvent} />
        </div>
      </div>

      {isLogging && (
        <LogTopicModal onClose={() => setIsLogging(false)} onSave={onLogTopic} />
      )}
    </div>
  );
}
