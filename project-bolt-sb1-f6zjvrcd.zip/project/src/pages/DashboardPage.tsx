import ResultsPanel from '@/components/ResultsPanel';
import UploadGrader from '@/components/UploadGrader';
import { todayKey } from '@/lib/dates';
import { createId } from '@/lib/ids';
import type { GradedPaper, GradeResult } from '@/types';

interface DashboardPageProps {
  papers: GradedPaper[];
  onPaperGraded: (paper: GradedPaper) => void;
}

export default function DashboardPage({ papers, onPaperGraded }: DashboardPageProps) {
  const handleGraded = (name: string, result: GradeResult) => {
    onPaperGraded({ id: createId(), name, gradedOn: todayKey(), result });
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-50 sm:text-3xl">Dashboard</h1>
        <p className="mt-1 text-sm text-slate-400">
          Upload a student paper and its mark scheme to get an instant examiner-style breakdown.
        </p>
      </div>

      <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <UploadGrader onGraded={handleGraded} />
        <ResultsPanel paper={papers[0] ?? null} />
      </div>
    </div>
  );
}
