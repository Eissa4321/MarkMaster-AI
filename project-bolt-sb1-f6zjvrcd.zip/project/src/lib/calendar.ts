import type { CalendarEvent, GradedPaper } from '@/types';
import { addDays } from '@/lib/dates';
import { createId } from '@/lib/ids';

export const RETRY_OFFSET_DAYS = 7;
export const TOPIC_REVIEW_OFFSETS = [1, 3, 7, 21];

export function buildPaperEvents(paper: GradedPaper): CalendarEvent[] {
  return [
    {
      id: createId(),
      kind: 'graded',
      title: `Graded: ${paper.name} (${paper.result.score}/${paper.result.maxScore})`,
      date: paper.gradedOn,
      done: true,
    },
    {
      id: createId(),
      kind: 'retry',
      title: `1-Week Retry: ${paper.name}`,
      date: addDays(paper.gradedOn, RETRY_OFFSET_DAYS),
      done: false,
    },
  ];
}

export function buildTopicEvents(topic: string, startDate: string): CalendarEvent[] {
  return TOPIC_REVIEW_OFFSETS.map((offset) => ({
    id: createId(),
    kind: 'topic-review',
    title: `Day ${offset} review: ${topic}`,
    date: addDays(startDate, offset),
    done: false,
  }));
}
