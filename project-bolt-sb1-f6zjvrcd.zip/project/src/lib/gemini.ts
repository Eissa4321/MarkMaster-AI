import type { GradeResult } from '@/types';

export const ACCEPTED_MIME_TYPES = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/heic',
  'image/heif',
  'text/plain',
];

const MAX_TOTAL_BYTES = 4 * 1024 * 1024;

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? '');
      resolve(result.slice(result.indexOf(',') + 1));
    };
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

function isGradeResult(value: unknown): value is GradeResult {
  const data = value as Partial<GradeResult> | null;
  return (
    typeof data?.score === 'number' &&
    typeof data.maxScore === 'number' &&
    typeof data.percentage === 'number' &&
    typeof data.summary === 'string' &&
    Array.isArray(data.missedKeywords) &&
    Array.isArray(data.strengths) &&
    Array.isArray(data.improvements) &&
    Array.isArray(data.questionBreakdown)
  );
}

export async function gradePaper(studentFile: File, schemeFile: File): Promise<GradeResult> {
  if (studentFile.size + schemeFile.size > MAX_TOTAL_BYTES) {
    throw new Error('The two files together are too large (4 MB max). Try smaller scans.');
  }

  const [studentData, schemeData] = await Promise.all([
    readFileAsBase64(studentFile),
    readFileAsBase64(schemeFile),
  ]);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  let response: Response;
  try {
    response = await fetch(`${supabaseUrl}/functions/v1/grade-paper`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${anonKey}`,
        apikey: anonKey,
      },
      body: JSON.stringify({
        studentFile: { mimeType: studentFile.type, data: studentData },
        schemeFile: { mimeType: schemeFile.type, data: schemeData },
      }),
    });
  } catch {
    throw new Error('Could not reach the grading service. Check your connection and try again.');
  }

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    const message: string | undefined = payload?.error;
    throw new Error(message ?? `Grading failed (status ${response.status}). Please try again.`);
  }

  if (!isGradeResult(payload)) {
    throw new Error('The grader returned an unexpected response. Please try again.');
  }

  return payload;
}
