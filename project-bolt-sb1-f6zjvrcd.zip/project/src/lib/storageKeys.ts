export const STORAGE_KEYS = {
  papers: 'markmaster.papers',
  events: 'markmaster.calendarEvents',
} as const;
