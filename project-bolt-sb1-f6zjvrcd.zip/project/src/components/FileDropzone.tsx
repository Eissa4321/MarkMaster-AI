import { useRef, useState, type DragEvent } from 'react';
import { FileText, Upload, X } from 'lucide-react';

interface FileDropzoneProps {
  label: string;
  hint: string;
  file: File | null;
  onFileChange: (file: File | null) => void;
  disabled?: boolean;
}

const ACCEPT = '.pdf,.png,.jpg,.jpeg,.webp,.heic,.heif,.txt';

function formatSize(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function FileDropzone({
  label,
  hint,
  file,
  onFileChange,
  disabled,
}: FileDropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    if (disabled) return;
    const dropped = event.dataTransfer.files?.[0];
    if (dropped) onFileChange(dropped);
  };

  return (
    <div className="flex flex-col gap-2">
      <p className="text-sm font-medium text-slate-200">{label}</p>
      {file ? (
        <div className="flex items-center gap-3 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15">
            <FileText className="h-5 w-5 text-emerald-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-slate-100">{file.name}</p>
            <p className="text-xs text-slate-400">{formatSize(file.size)}</p>
          </div>
          <button
            type="button"
            onClick={() => onFileChange(null)}
            disabled={disabled}
            aria-label={`Remove ${label}`}
            className="rounded-md p-2 text-slate-400 transition-colors hover:bg-white/5 hover:text-rose-300 disabled:opacity-50"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <div
          role="button"
          tabIndex={0}
          onClick={() => !disabled && inputRef.current?.click()}
          onKeyDown={(event) => {
            if ((event.key === 'Enter' || event.key === ' ') && !disabled) {
              event.preventDefault();
              inputRef.current?.click();
            }
          }}
          onDragOver={(event) => {
            event.preventDefault();
            if (!disabled) setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-8 text-center transition-all duration-200 ${
            isDragging
              ? 'border-sky-400 bg-sky-500/10'
              : 'border-white/15 bg-slate-950/60 hover:border-sky-400/50 hover:bg-slate-900'
          } ${disabled ? 'cursor-not-allowed opacity-50' : ''}`}
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-slate-800">
            <Upload className="h-5 w-5 text-sky-400" />
          </div>
          <p className="text-sm font-medium text-slate-200">Drop a file or click to browse</p>
          <p className="text-xs text-slate-500">{hint}</p>
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT}
        className="hidden"
        disabled={disabled}
        onChange={(event) => {
          const selected = event.target.files?.[0] ?? null;
          if (selected) onFileChange(selected);
          event.target.value = '';
        }}
      />
    </div>
  );
}
