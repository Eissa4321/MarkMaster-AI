import { AlertTriangle, CheckCircle2, ClipboardList, Lightbulb, Target } from 'lucide-react';
import type { GradedPaper, QuestionFeedback } from '@/types';
import { formatDateLabel } from '@/lib/dates';

interface ResultsPanelProps {
  paper: GradedPaper | null;
}

function ScoreRing({ percentage }: { percentage: number }) {
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.min(100, Math.max(0, percentage));
  const offset = circumference - (clamped / 100) * circumference;
  const color = clamped >= 70 ? 'text-emerald-400' : clamped >= 50 ? 'text-amber-400' : 'text-rose-400';

  return (
    <div className="relative h-36 w-36 shrink-0">
      <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
        <circle cx="60" cy="60" r={radius} strokeWidth="10" className="fill-none stroke-slate-800" />
        <circle
          cx="60"
          cy="60"
          r={radius}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className={`fill-none stroke-current ${color} transition-[stroke-dashoffset] duration-700 ease-out`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold text-slate-50">{clamped}%</span>
        <span className="text-xs text-slate-400">Score</span>
      </div>
    </div>
  );
}

function QuestionRow({ item }: { item: QuestionFeedback }) {
  const ratio = item.maxMarks > 0 ? Math.min(100, (item.marksAwarded / item.maxMarks) * 100) : 0;
  return (
    <li className="rounded-xl border border-white/10 bg-slate-950/50 p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-medium text-slate-100">{item.question}</p>
        <span className="shrink-0 rounded-md bg-slate-800 px-2 py-0.5 font-mono text-xs text-slate-200">
          {item.marksAwarded}/{item.maxMarks}
        </span>
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-emerald-400 transition-[width] duration-700 ease-out"
          style={{ width: `${ratio}%` }}
        />
      </div>
      <p className="mt-3 text-sm leading-relaxed text-slate-400">{item.comment}</p>
    </li>
  );
}

function BulletList({
  title,
  items,
  icon: Icon,
  tone,
}: {
  title: string;
  items: string[];
  icon: typeof CheckCircle2;
  tone: string;
}) {
  return (
    <div className="rounded-xl border border-white/10 bg-slate-950/50 p-4">
      <h3 className={`mb-3 flex items-center gap-2 text-sm font-semibold ${tone}`}>
        <Icon className="h-4 w-4" />
        {title}
      </h3>
      {items.length > 0 ? (
        <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
          {items.map((item, index) => (
            <li key={index} className="flex gap-2">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-current opacity-60" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-slate-500">None noted.</p>
      )}
    </div>
  );
}

export default function ResultsPanel({ paper }: ResultsPanelProps) {
  if (!paper) {
    return (
      <section className="flex h-full min-h-[320px] flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 bg-slate-900/40 p-8 text-center">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-slate-800">
          <ClipboardList className="h-5 w-5 text-slate-400" />
        </div>
        <h2 className="text-base font-semibold text-slate-200">No results yet</h2>
        <p className="mt-2 max-w-xs text-sm text-slate-500">
          Grade a paper and its score, missed keywords and feedback will appear here.
        </p>
      </section>
    );
  }

  const { result } = paper;

  return (
    <section className="flex flex-col gap-6 rounded-2xl border border-white/10 bg-slate-900/60 p-5 shadow-xl shadow-black/20 sm:p-6">
      <div>
        <p className="text-xs uppercase tracking-wider text-slate-500">
          Graded {formatDateLabel(paper.gradedOn)}
        </p>
        <h2 className="mt-1 truncate text-lg font-semibold text-slate-50">{paper.name}</h2>
      </div>

      <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-center">
        <ScoreRing percentage={result.percentage} />
        <div className="flex-1 text-center sm:text-left">
          <p className="text-4xl font-bold tracking-tight text-slate-50">
            {result.score}
            <span className="text-2xl font-medium text-slate-500"> / {result.maxScore}</span>
          </p>
          <p className="mt-3 text-sm leading-relaxed text-slate-300">{result.summary}</p>
        </div>
      </div>

      <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-rose-300">
          <Target className="h-4 w-4" />
          Missed keywords
        </h3>
        {result.missedKeywords.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {result.missedKeywords.map((keyword) => (
              <span
                key={keyword}
                className="inline-flex items-center gap-1.5 rounded-full border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-xs font-medium text-rose-200"
              >
                <AlertTriangle className="h-3 w-3" />
                {keyword}
              </span>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-400">No key terms missed.</p>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <BulletList
          title="Strengths"
          items={result.strengths}
          icon={CheckCircle2}
          tone="text-emerald-300"
        />
        <BulletList
          title="To improve"
          items={result.improvements}
          icon={Lightbulb}
          tone="text-amber-300"
        />
      </div>

      {result.questionBreakdown.length > 0 && (
        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-200">Feedback breakdown</h3>
          <ul className="space-y-3">
            {result.questionBreakdown.map((item, index) => (
              <QuestionRow key={`${item.question}-${index}`} item={item} />
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
