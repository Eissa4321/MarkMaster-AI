import { useState } from 'react';
import { AlertCircle, Loader2, Sparkles } from 'lucide-react';
import FileDropzone from '@/components/FileDropzone';
import { ACCEPTED_MIME_TYPES, gradePaper } from '@/lib/gemini';
import type { GradeResult } from '@/types';

interface UploadGraderProps {
  onGraded: (name: string, result: GradeResult) => void;
}

export default function UploadGrader({ onGraded }: UploadGraderProps) {
  const [studentFile, setStudentFile] = useState<File | null>(null);
  const [schemeFile, setSchemeFile] = useState<File | null>(null);
  const [isGrading, setIsGrading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canGrade = Boolean(studentFile && schemeFile) && !isGrading;

  const handleGrade = async () => {
    if (!studentFile || !schemeFile) return;

    const unsupported = [studentFile, schemeFile].find(
      (file) => !ACCEPTED_MIME_TYPES.includes(file.type),
    );
    if (unsupported) {
      setError(`"${unsupported.name}" is not a supported format. Use PDF, PNG, JPG, WEBP or TXT.`);
      return;
    }

    setError(null);
    setIsGrading(true);
    try {
      const result = await gradePaper(studentFile, schemeFile);
      onGraded(studentFile.name, result);
      setStudentFile(null);
      setSchemeFile(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong while grading.');
    } finally {
      setIsGrading(false);
    }
  };

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5 shadow-xl shadow-black/20 sm:p-6">
      <div className="mb-5">
        <h2 className="text-base font-semibold text-slate-50">Grade a past paper</h2>
        <p className="mt-1 text-sm text-slate-400">
          Upload the student's answers and the official mark scheme.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        <FileDropzone
          label="Student Paper"
          hint="PDF, PNG, JPG, WEBP or TXT"
          file={studentFile}
          onFileChange={setStudentFile}
          disabled={isGrading}
        />
        <FileDropzone
          label="Mark Scheme"
          hint="PDF, PNG, JPG, WEBP or TXT"
          file={schemeFile}
          onFileChange={setSchemeFile}
          disabled={isGrading}
        />
      </div>

      {error && (
        <div
          role="alert"
          className="mt-5 flex items-start gap-2.5 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3.5 text-sm text-rose-200"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
          <p>{error}</p>
        </div>
      )}

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-slate-500">
          Files are sent securely for marking. Results appear on the right.
        </p>
        <button
          type="button"
          onClick={handleGrade}
          disabled={!canGrade}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-emerald-500/20 transition-all hover:bg-emerald-400 hover:-translate-y-0.5 disabled:translate-y-0 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-400 disabled:shadow-none"
        >
          {isGrading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Grading paper...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              Grade Paper
            </>
          )}
        </button>
      </div>
    </section>
  );
}
