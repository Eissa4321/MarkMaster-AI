import { BookMarked, Check, RotateCcw, Trash2 } from 'lucide-react';
import type { CalendarEvent, CalendarEventKind } from '@/types';
import { formatDateLabel } from '@/lib/dates';

export const EVENT_KIND_META: Record<
  CalendarEventKind,
  { label: string; dot: string; badge: string; icon: typeof Check }
> = {
  graded: {
    label: 'Graded',
    dot: 'bg-emerald-400',
    badge: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300',
    icon: Check,
  },
  retry: {
    label: '1-Week Retry',
    dot: 'bg-amber-400',
    badge: 'border-amber-400/30 bg-amber-500/10 text-amber-300',
    icon: RotateCcw,
  },
  'topic-review': {
    label: 'Spaced Review',
    dot: 'bg-sky-400',
    badge: 'border-sky-400/30 bg-sky-500/10 text-sky-300',
    icon: BookMarked,
  },
};

interface EventRowProps {
  event: CalendarEvent;
  showDate?: boolean;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function EventRow({ event, showDate, onToggle, onDelete }: EventRowProps) {
  const meta = EVENT_KIND_META[event.kind];
  const Icon = meta.icon;

  return (
    <li className="group flex items-start gap-3 rounded-xl border border-white/10 bg-slate-950/50 p-3.5 transition-colors hover:border-white/20">
      <button
        type="button"
        onClick={() => onToggle(event.id)}
        aria-label={event.done ? 'Mark as not done' : 'Mark as done'}
        aria-pressed={event.done}
        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-all duration-200 ${
          event.done
            ? 'border-emerald-400 bg-emerald-500 text-slate-950'
            : 'border-white/20 hover:border-emerald-400/60'
        }`}
      >
        {event.done && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
      </button>

      <div className="min-w-0 flex-1">
        <div className="mb-1.5 flex flex-wrap items-center gap-2">
          <span
            className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium ${meta.badge}`}
          >
            <Icon className="h-3 w-3" />
            {meta.label}
          </span>
          {showDate && (
            <span className="text-[11px] text-slate-500">{formatDateLabel(event.date)}</span>
          )}
        </div>
        <p
          className={`text-sm leading-snug ${
            event.done ? 'text-slate-500 line-through' : 'text-slate-100'
          }`}
        >
          {event.title}
        </p>
      </div>

      <button
        type="button"
        onClick={() => onDelete(event.id)}
        aria-label="Delete event"
        className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-rose-500/10 hover:text-rose-300"
      >
        <Trash2 className="h-4 w-4" />
      </button>
    </li>
  );
}
