import EventRow from '@/components/calendar/EventRow';
import type { CalendarEvent } from '@/types';

interface UpcomingRemindersProps {
  events: CalendarEvent[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function UpcomingReminders({ events, onToggle, onDelete }: UpcomingRemindersProps) {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5 shadow-xl shadow-black/20 sm:p-6">
      <h2 className="mb-4 text-base font-semibold text-slate-50">Up next</h2>
      {events.length > 0 ? (
        <ul className="flex flex-col gap-3">
          {events.map((event) => (
            <EventRow
              key={event.id}
              event={event}
              showDate
              onToggle={onToggle}
              onDelete={onDelete}
            />
          ))}
        </ul>
      ) : (
        <p className="text-sm text-slate-500">All caught up. No reviews are due.</p>
      )}
    </section>
  );
}
