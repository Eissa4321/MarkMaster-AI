import { ChevronLeft, ChevronRight } from 'lucide-react';
import { EVENT_KIND_META } from '@/components/calendar/EventRow';
import { toDateKey } from '@/lib/dates';
import type { CalendarEvent } from '@/types';

interface MonthGridProps {
  month: Date;
  selectedDate: string;
  todayKey: string;
  eventsByDate: Map<string, CalendarEvent[]>;
  onMonthChange: (month: Date) => void;
  onSelectDate: (date: string) => void;
}

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function MonthGrid({
  month,
  selectedDate,
  todayKey,
  eventsByDate,
  onMonthChange,
  onSelectDate,
}: MonthGridProps) {
  const year = month.getFullYear();
  const monthIndex = month.getMonth();
  const leadingBlanks = (new Date(year, monthIndex, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

  const cells: (string | null)[] = [
    ...Array.from({ length: leadingBlanks }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) =>
      toDateKey(new Date(year, monthIndex, i + 1)),
    ),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const monthLabel = month.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 shadow-xl shadow-black/20 sm:p-6">
      <div className="mb-5 flex items-center justify-between gap-2">
        <h2 className="text-lg font-semibold text-slate-50">{monthLabel}</h2>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onMonthChange(new Date(year, monthIndex - 1, 1))}
            aria-label="Previous month"
            className="rounded-lg border border-white/10 p-2 text-slate-300 transition-colors hover:bg-white/5 hover:text-slate-50"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              const now = new Date();
              onMonthChange(new Date(now.getFullYear(), now.getMonth(), 1));
              onSelectDate(todayKey);
            }}
            className="rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-slate-50"
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => onMonthChange(new Date(year, monthIndex + 1, 1))}
            aria-label="Next month"
            className="rounded-lg border border-white/10 p-2 text-slate-300 transition-colors hover:bg-white/5 hover:text-slate-50"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 pb-2">
        {WEEKDAYS.map((day) => (
          <div key={day} className="text-center text-[11px] font-medium uppercase tracking-wider text-slate-500">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {cells.map((key, index) => {
          if (!key) return <div key={`blank-${index}`} className="aspect-square" />;

          const dayEvents = eventsByDate.get(key) ?? [];
          const isSelected = key === selectedDate;
          const isToday = key === todayKey;
          const dayNumber = Number(key.slice(-2));
          const uniqueKinds = Array.from(new Set(dayEvents.map((e) => e.kind))).slice(0, 3);

          return (
            <button
              key={key}
              type="button"
              onClick={() => onSelectDate(key)}
              aria-pressed={isSelected}
              className={`flex aspect-square flex-col items-center justify-between rounded-xl border p-1.5 text-sm transition-all duration-200 sm:p-2 ${
                isSelected
                  ? 'border-emerald-400/60 bg-emerald-500/15 text-slate-50'
                  : 'border-transparent text-slate-300 hover:border-white/10 hover:bg-white/5'
              }`}
            >
              <span
                className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-medium sm:h-8 sm:w-8 sm:text-sm ${
                  isToday ? 'bg-sky-500 text-slate-950 font-semibold' : ''
                }`}
              >
                {dayNumber}
              </span>
              <span className="flex h-1.5 items-center gap-1">
                {uniqueKinds.map((kind) => (
                  <span key={kind} className={`h-1.5 w-1.5 rounded-full ${EVENT_KIND_META[kind].dot}`} />
                ))}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
