import { CalendarCheck2 } from 'lucide-react';
import EventRow from '@/components/calendar/EventRow';
import { formatDateLabel } from '@/lib/dates';
import type { CalendarEvent } from '@/types';

interface DayAgendaProps {
  date: string;
  events: CalendarEvent[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function DayAgenda({ date, events, onToggle, onDelete }: DayAgendaProps) {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5 shadow-xl shadow-black/20 sm:p-6">
      <p className="text-xs uppercase tracking-wider text-slate-500">Selected day</p>
      <h2 className="mt-1 mb-4 text-base font-semibold text-slate-50">{formatDateLabel(date)}</h2>

      {events.length > 0 ? (
        <ul className="flex flex-col gap-3">
          {events.map((event) => (
            <EventRow key={event.id} event={event} onToggle={onToggle} onDelete={onDelete} />
          ))}
        </ul>
      ) : (
        <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-white/10 py-8 text-center">
          <CalendarCheck2 className="h-5 w-5 text-slate-500" />
          <p className="text-sm text-slate-500">Nothing scheduled for this day.</p>
        </div>
      )}
    </section>
  );
}
