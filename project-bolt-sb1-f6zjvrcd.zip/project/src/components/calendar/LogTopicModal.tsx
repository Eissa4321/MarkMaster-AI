import { useState, type FormEvent } from 'react';
import { BookPlus, X } from 'lucide-react';
import { TOPIC_REVIEW_OFFSETS } from '@/lib/calendar';
import { addDays, formatDateLabel, todayKey } from '@/lib/dates';

interface LogTopicModalProps {
  onClose: () => void;
  onSave: (topic: string, startDate: string) => void;
}

export default function LogTopicModal({ onClose, onSave }: LogTopicModalProps) {
  const [topic, setTopic] = useState('');
  const [startDate, setStartDate] = useState(todayKey());

  const trimmed = topic.trim();

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!trimmed || !startDate) return;
    onSave(trimmed, startDate);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/70 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      onKeyDown={(event) => {
        if (event.key === 'Escape') onClose();
      }}
    >
      <form
        onSubmit={handleSubmit}
        role="dialog"
        aria-modal="true"
        aria-labelledby="log-topic-title"
        className="w-full max-w-md rounded-t-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl sm:rounded-2xl"
      >
        <div className="mb-5 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/15 ring-1 ring-sky-400/30">
              <BookPlus className="h-5 w-5 text-sky-400" />
            </div>
            <div>
              <h2 id="log-topic-title" className="text-base font-semibold text-slate-50">
                Log Study Topic
              </h2>
              <p className="text-xs text-slate-400">Schedule spaced repetition reviews</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-white/5 hover:text-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex flex-col gap-4">
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-slate-200">Topic</span>
            <input
              autoFocus
              value={topic}
              onChange={(event) => setTopic(event.target.value)}
              placeholder="e.g. Photosynthesis light-dependent reactions"
              maxLength={120}
              className="rounded-lg border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-400/60 focus:outline-none focus:ring-2 focus:ring-sky-400/20"
            />
          </label>

          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-slate-200">Studied on</span>
            <input
              type="date"
              value={startDate}
              onChange={(event) => setStartDate(event.target.value)}
              className="rounded-lg border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-100 focus:border-sky-400/60 focus:outline-none focus:ring-2 focus:ring-sky-400/20 [color-scheme:dark]"
            />
          </label>

          <div className="rounded-xl border border-white/10 bg-slate-950/60 p-4">
            <p className="mb-3 text-xs font-medium uppercase tracking-wider text-slate-500">
              Review schedule
            </p>
            <ul className="grid grid-cols-2 gap-2 text-sm">
              {TOPIC_REVIEW_OFFSETS.map((offset) => (
                <li key={offset} className="flex flex-col rounded-lg bg-slate-900 px-3 py-2">
                  <span className="text-xs text-sky-300">Day {offset}</span>
                  <span className="text-slate-200">{formatDateLabel(addDays(startDate, offset))}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-white/10 px-4 py-2.5 text-sm font-medium text-slate-300 transition-colors hover:bg-white/5"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={!trimmed || !startDate}
            className="rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-slate-950 transition-all hover:bg-sky-400 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-400"
          >
            Schedule reviews
          </button>
        </div>
      </form>
    </div>
  );
}
