export interface QuestionFeedback {
  question: string;
  marksAwarded: number;
  maxMarks: number;
  comment: string;
}

export interface GradeResult {
  score: number;
  maxScore: number;
  percentage: number;
  summary: string;
  missedKeywords: string[];
  strengths: string[];
  improvements: string[];
  questionBreakdown: QuestionFeedback[];
}

export interface GradedPaper {
  id: string;
  name: string;
  gradedOn: string;
  result: GradeResult;
}

export type CalendarEventKind = 'graded' | 'retry' | 'topic-review';

export interface CalendarEvent {
  id: string;
  kind: CalendarEventKind;
  title: string;
  date: string;
  done: boolean;
}
