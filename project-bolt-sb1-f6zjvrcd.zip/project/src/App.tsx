import { useState } from 'react';
import AppHeader, { type AppTab } from '@/components/AppHeader';
import { usePersistentState } from '@/hooks/usePersistentState';
import { buildPaperEvents, buildTopicEvents } from '@/lib/calendar';
import { STORAGE_KEYS } from '@/lib/storageKeys';
import DashboardPage from '@/pages/DashboardPage';
import RevisionCalendarPage from '@/pages/RevisionCalendarPage';
import type { CalendarEvent, GradedPaper } from '@/types';

function App() {
  const [tab, setTab] = useState<AppTab>('dashboard');
  const [papers, setPapers] = usePersistentState<GradedPaper[]>(STORAGE_KEYS.papers, []);
  const [events, setEvents] = usePersistentState<CalendarEvent[]>(STORAGE_KEYS.events, []);

  const handlePaperGraded = (paper: GradedPaper) => {
    setPapers((prev) => [paper, ...prev]);
    setEvents((prev) => [...prev, ...buildPaperEvents(paper)]);
  };

  const handleLogTopic = (topic: string, startDate: string) => {
    setEvents((prev) => [...prev, ...buildTopicEvents(topic, startDate)]);
  };

  const handleToggleEvent = (id: string) => {
    setEvents((prev) =>
      prev.map((event) => (event.id === id ? { ...event, done: !event.done } : event)),
    );
  };

  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((event) => event.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased">
      <AppHeader activeTab={tab} onTabChange={setTab} />
      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
        {tab === 'dashboard' ? (
          <DashboardPage papers={papers} onPaperGraded={handlePaperGraded} />
        ) : (
          <RevisionCalendarPage
            events={events}
            onToggleEvent={handleToggleEvent}
            onDeleteEvent={handleDeleteEvent}
            onLogTopic={handleLogTopic}
          />
        )}
      </main>
    </div>
  );
}

export default App;
